from multiprocessing import pool
import pygame
import os
from os import name
import pyautogui
from sty import fg, bg, ef, rs
from sty import Style, RgbFg
import sys
import random
import time
from threading import *
import webbrowser

#{ <Other>
pygame.init()
FPS60=60

kier=(u'\u2661')
pik=(u'\u2660')
romb=(u'\u2662')
trefl=(u'\u2663')

Player0_money_space=(435, 455)
Player1_money_space=(215, 365)
Player2_money_space=(120, 235)
Player3_money_space=(220, 120)
Player4_money_space=(430, 30)
Player5_money_space=(650, 120)
Player6_money_space=(750, 235)
Player7_money_space=(650, 370)

Player0_space=(430, 350)
Player1_space=(270, 330)
Player2_space=(240, 235)
Player3_space=(275, 160)
Player4_space=(430, 125)
Player5_space=(570, 160)
Player6_space=(620, 235)
Player7_space=(585, 330)

White=(255, 255, 255)
Black=(0, 0, 0)
Green=(0, 255, 0)
Red=(255, 0, 0)
Blue=(0, 0, 255)
Yellow=(225, 225, 0)
Button_not_clicked_colour=(100, 100, 100)
Button_clicked_colour=(195, 195, 195)

new_game_button_cordsx, new_game_button_cordsy = (200, 75)
continue_button_cordsx, continue_button_cordsy = (150, 135)
settings_button_cordsx, settings_button_cordsy = (100, 195)
info_button_cordsx, info_button_cordsy = (50, 255)
get_code_button_cordsx, get_code_button_cordsy = (75, 420)

button_font = pygame.font.SysFont('Corbel',35) # rendering a text written in this font
button_sizex, button_sizey = (140, 40) #buttons sizes

how_to_play_button_sizex, how_to_play_button_sizey = (400, 300) #size of buttons(ellipse(how to play))
how_to_play_button_cordsx, how_to_play_button_cordsy = (420, 80)

back_to_main_menu_button_cordsx, back_to_main_menu_button_cordsy = (30, 435)

cards_font = pygame.font.SysFont('arial', 15)
names_font = pygame.font.SysFont('arial', 20)
player_spaces_font = pygame.font.SysFont('arial', 20)
Players_money_fonts = pygame.font.SysFont('arial', 20)


Button_dic={}
Small_dic={}
Big_dic={}

"Player0">"Player1">"Player2">"Player3">"Player4">"Player5">"Player6">"Player7"
order=["Player0","Player1","Player2","Player3","Player4","Player5","Player6","Player7"]
queue=[]
new_list=[]
current_player_in_queue_list=[]
blinds_money_value=[]
choices=["pass", "check","check","check","check","check","bid"]
passed_players=[]
last_to_check=[]
check_count=0
pool_sum=0

#}



#{ <Window>
GAME_WIDTH=900
GAME_HEIGHT=500
WIN=pygame.display.set_mode((GAME_WIDTH, GAME_HEIGHT))
pygame.display.set_caption("Poker") #shows file name

ellipse_width=500
ellipse_height=300

width = WIN.get_width()
height = WIN.get_height()

trapezoid_coordinates=((0, 0),(width/2, 0),(width/4, height),(0, height))
#}



#{ <cards>
all_cards = ["2"+kier,"3"+kier,"4"+kier,"5"+kier,"6"+kier,"7"+kier,"8"+kier,"9"+kier,"10"+kier,"J"+kier,"Q"+kier,"K"+kier,"A"+kier,
"2"+pik,"3"+pik,"4"+pik,"5"+pik,"6"+pik,"7"+pik,"8"+pik,"9"+pik,"10"+pik,"J"+pik,"Q"+pik,"K"+pik,"A"+pik,
"2"+romb,"3"+romb,"4"+romb,"5"+romb,"6"+romb,"7"+romb,"8"+romb,"9"+romb,"10"+romb,"J"+romb,"Q"+romb,"K"+romb,"A"+romb,
"2"+trefl,"3"+trefl,"4"+trefl,"5"+trefl,"6"+trefl,"7"+trefl,"8"+trefl,"9"+trefl,"10"+trefl,"J"+trefl,"Q"+trefl,"K"+trefl,"A"+trefl]

available_cards = ["2"+kier,"3"+kier,"4"+kier,"5"+kier,"6"+kier,"7"+kier,"8"+kier,"9"+kier,"10"+kier,"J"+kier,"Q"+kier,"K"+kier,"A"+kier,
"2"+pik,"3"+pik,"4"+pik,"5"+pik,"6"+pik,"7"+pik,"8"+pik,"9"+pik,"10"+pik,"J"+pik,"Q"+pik,"K"+pik,"A"+pik,
"2"+romb,"3"+romb,"4"+romb,"5"+romb,"6"+romb,"7"+romb,"8"+romb,"9"+romb,"10"+romb,"J"+romb,"Q"+romb,"K"+romb,"A"+romb,
"2"+trefl,"3"+trefl,"4"+trefl,"5"+trefl,"6"+trefl,"7"+trefl,"8"+trefl,"9"+trefl,"10"+trefl,"J"+trefl,"Q"+trefl,"K"+trefl,"A"+trefl]


middle_card_slot0=[]
middle_card_slot1=[]
middle_card_slot2=[]
middle_card_slot3=[]
middle_card_slot4=[]

all_middle_cards=[middle_card_slot0, middle_card_slot1, middle_card_slot2, middle_card_slot3, middle_card_slot4]

middle_cards_to_show=[]

show_mid_cards_all = False
show_middle_cards_2 = False
show_middle_cards_3 = False
#}



#{ <players>
player0=[]
player1=[]
player2=[]
player3=[]
player4=[]
player5=[]
player6=[]
player7=[]

all_players=[player0,player1,player2,player3,player4,player5,player6,player7]
#}



#{ <money>
Players_money_dic={
    "Player0":100,
    
    "Player1":100,

    "Player2":100,

    "Player3":100,

    "Player4":100,
    
    "Player5":100,

    "Player6":100,
    
    "Player7":100,
}

Players_money_dic_queue={}
#}
