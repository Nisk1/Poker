#{ <Uwagi>

#}



from Data import *

#{ <Other>
def clo(): #clears last output in terminal
    sys.stdout.write("\033[F") #backs to previous line 
    sys.stdout.write("\033[K") #clears line

def clearscreen(): #clears terminal
    if name == 'nt': #defines operating system users using
        _= os.system("cls") #for windows
    else:
        _= os.system("clear") #for linux and mac

def window_fill_colour(colour): #fills window with colour (colour)
    WIN.fill(colour)

def pool_rectangle(): #creates black rectangle that shows amount money in a pool
    pygame.draw.rect(WIN, Black, ((375, 275),(150,50)), width=0)

def ellipse(): #creates green ellipse
    pygame.draw.ellipse(WIN, Green, (int((GAME_WIDTH-ellipse_width)/2), int((GAME_HEIGHT-ellipse_height)/2), ellipse_width, ellipse_height))
#}



#{ <Menu>
def main_menu_my_img(): #creates photo of me in main menu
    MAIN_MENU_ME_IMAGE=pygame.image.load(os.path.join("Nisk1_menu1.jpg")) #loads image
    MAIN_MENU_ME=pygame.transform.scale(MAIN_MENU_ME_IMAGE, (GAME_WIDTH, GAME_HEIGHT)) #resize image
    WIN.blit(MAIN_MENU_ME, (0, 0)) #blits MAIN_MENU to window on x0, y0

def grey_shadow_main_menu(surface, colour, points): #makes grey transparent trapezoid (idk how it works (https://stackoverflow.com/a/64630102))
    #link to the post: https://stackoverflow.com/questions/6339057/draw-a-transparent-rectangles-and-polygons-in-pygame
    #link to the answer: https://stackoverflow.com/a/64630102 (user: Rabbid76)

    lx, ly = zip(*points)
    min_x, min_y, max_x, max_y = min(lx), min(ly), max(lx), max(ly)
    target_rect = pygame.Rect(min_x, min_y, max_x - min_x, max_y - min_y)
    shape_surf = pygame.Surface(target_rect.size, pygame.SRCALPHA)
    pygame.draw.polygon(shape_surf, colour, [(x - min_x, y - min_y) for x, y in points])
    surface.blit(shape_surf, target_rect)

def main_menu_how_to_play_img(): #creates poker photo in main menu (how to play)
    MAIN_MENU_POKER_IMAGE=pygame.image.load(os.path.join("Poker_img_how_to_play.jpg")) #loads image
    MAIN_MENU_POKER=pygame.transform.scale(MAIN_MENU_POKER_IMAGE, (300, 180)) #resize image
    WIN.blit(MAIN_MENU_POKER, (470, 140)) #blits MAIN_MENU_POKER to window on x470, y140

def all_buttons_main_menu(): #creates all buttons in main menu

    #{ <how buttons are made>
    #buttons are made out of 2 rectangles and text,
    #whenever mouse is on button rectange changes colour,
    #and when mouse is clicked specific action is made.
    #}

    #{ <creates all buttons names>
    made_by_Nisk1 = button_font.render('Made by Nisk1' , True , Black)
    how_to_play_button_Black = button_font.render('How to play' , True , Black)
    how_to_play_button_White = button_font.render('How to play' , True , White) 
    new_game_button = button_font.render('New Game' , True , Black)
    continue_button = button_font.render('Continue' , True , Black)
    settings_button = button_font.render('Settings' , True , Black)
    info_button = button_font.render('Info' , True , Black)
    get_code_button = button_font.render('Code' , True , Black)
    #}

    run=True
    clock=pygame.time.Clock()
    while run:
        clock.tick(FPS60) #makes sure loop runs 60 times per second
        for ev in pygame.event.get():

            if ev.type == pygame.QUIT: #checks if users closes program
                run=False

            if ev.type == pygame.MOUSEBUTTONDOWN: #if the mouse is clicked on the button(new game) the (main_game()) is opend
                if new_game_button_cordsx <= mouse[0] <= new_game_button_cordsx+button_sizex and new_game_button_cordsy <= mouse[1] <= new_game_button_cordsy+button_sizey:
                    main_game()

            if ev.type == pygame.MOUSEBUTTONDOWN: #if the mouse is clicked on the button(contine) the (main_continue_main_menu()) is opend
                if continue_button_cordsx <= mouse[0] <= continue_button_cordsx+button_sizex and continue_button_cordsy <= mouse[1] <= continue_button_cordsy+button_sizey:
                    main_continue_main_menu()

            if ev.type == pygame.MOUSEBUTTONDOWN: #if the mouse is clicked on the button(settings) the (main_settings_main_menu()) is opend
                if settings_button_cordsx <= mouse[0] <= settings_button_cordsx+button_sizex and settings_button_cordsy <= mouse[1] <= settings_button_cordsy+button_sizey:
                    main_settings_main_menu()

            if ev.type == pygame.MOUSEBUTTONDOWN: #if the mouse is clicked on the button(info) the (main_info_main_menu()) is opend
                if info_button_cordsx <= mouse[0] <= info_button_cordsx+button_sizex and info_button_cordsy <= mouse[1] <= info_button_cordsy+button_sizey:
                    main_info_main_menu() 

            if ev.type == pygame.MOUSEBUTTONDOWN: #if the mouse is clicked on the button(code) opens my github
                if get_code_button_cordsx <= mouse[0] <= get_code_button_cordsx+button_sizex and get_code_button_cordsy <= mouse[1] <= get_code_button_cordsy+button_sizey:
                    code_main_menu() 

            if ev.type == pygame.MOUSEBUTTONDOWN: #if the mouse is clicked on the button(how to play) the (main_how_to_play_main_menu()) is opend
                if how_to_play_button_cordsx <= mouse[0] <= how_to_play_button_cordsx+how_to_play_button_sizex and how_to_play_button_cordsy <= mouse[1] <= how_to_play_button_cordsy+how_to_play_button_sizey:
                    main_how_to_play_main_menu()

        mouse = pygame.mouse.get_pos() #gets position of the mouse

        #{ <creates rectangles that changes colours when hovered on>

        #new_game_button{
        if new_game_button_cordsx <= mouse[0] <= new_game_button_cordsx+button_sizex and new_game_button_cordsy <= mouse[1] <= new_game_button_cordsy+button_sizey: #<--- clicked
            pygame.draw.rect(WIN,Button_clicked_colour,[new_game_button_cordsx, new_game_button_cordsy, button_sizex, button_sizey])
        else: #<--- not clicked
            pygame.draw.rect(WIN,Button_not_clicked_colour,[new_game_button_cordsx, new_game_button_cordsy, button_sizex, button_sizey])
        #}

        #continue_button{
        if continue_button_cordsx <= mouse[0] <= continue_button_cordsx+button_sizex and continue_button_cordsy <= mouse[1] <= continue_button_cordsy+button_sizey: #<--- clicked
            pygame.draw.rect(WIN,Button_clicked_colour,[continue_button_cordsx, continue_button_cordsy, button_sizex, button_sizey])
        else: #<--- not clicked
            pygame.draw.rect(WIN,Button_not_clicked_colour,[continue_button_cordsx, continue_button_cordsy, button_sizex, button_sizey])
        #}

        #settings_button{
        if settings_button_cordsx <= mouse[0] <= settings_button_cordsx+button_sizex and settings_button_cordsy <= mouse[1] <= settings_button_cordsy+button_sizey: #<--- clicked
            pygame.draw.rect(WIN,Button_clicked_colour,[settings_button_cordsx, settings_button_cordsy, button_sizex, button_sizey])
        else: #<--- not clicked
            pygame.draw.rect(WIN,Button_not_clicked_colour,[settings_button_cordsx, settings_button_cordsy, button_sizex, button_sizey])
        #}

        #info_button{
        if info_button_cordsx <= mouse[0] <= info_button_cordsx+button_sizex and info_button_cordsy <= mouse[1] <= info_button_cordsy+button_sizey: #<--- clicked
            pygame.draw.rect(WIN,Button_clicked_colour,[info_button_cordsx, info_button_cordsy, button_sizex, button_sizey])
        else: #<--- not clicked
            pygame.draw.rect(WIN,Button_not_clicked_colour,[info_button_cordsx, info_button_cordsy, button_sizex, button_sizey])
        #}

        #get_code_button{
        if get_code_button_cordsx <= mouse[0] <= get_code_button_cordsx+button_sizex and get_code_button_cordsy <= mouse[1] <= get_code_button_cordsy+button_sizey: #<--- clicked
            pygame.draw.rect(WIN,Button_clicked_colour,[get_code_button_cordsx, get_code_button_cordsy, button_sizex, button_sizey])
        else: #<--- not clicked
            pygame.draw.rect(WIN,Button_not_clicked_colour,[get_code_button_cordsx, get_code_button_cordsy, button_sizex, button_sizey])
        #}

        #how_to_play_button{
        if how_to_play_button_cordsx <= mouse[0] <= how_to_play_button_cordsx+how_to_play_button_sizex and how_to_play_button_cordsy <= mouse[1] <= how_to_play_button_cordsy+how_to_play_button_sizey: #<--- clicked
            pygame.draw.ellipse(WIN,Button_clicked_colour,[how_to_play_button_cordsx, how_to_play_button_cordsy, how_to_play_button_sizex, how_to_play_button_sizey],width=0)
            WIN.blit(how_to_play_button_Black, (how_to_play_button_cordsx+130, how_to_play_button_cordsy+20))
        
        else: #<--- not clicked
            pygame.draw.ellipse(WIN,Black,[how_to_play_button_cordsx, how_to_play_button_cordsy, how_to_play_button_sizex, how_to_play_button_sizey],width=0)
            WIN.blit(how_to_play_button_White, (how_to_play_button_cordsx+130, how_to_play_button_cordsy+20))
        #}

        #}

        #{ <puts all buttin names onto rectangles(buttons)>  
        WIN.blit(new_game_button, (new_game_button_cordsx+5, new_game_button_cordsy+7.5))
        WIN.blit(continue_button, (continue_button_cordsx+15, continue_button_cordsy+7.5))
        WIN.blit(settings_button, (settings_button_cordsx+18.5, settings_button_cordsy+7.5))
        WIN.blit(info_button, (info_button_cordsx+48.5, info_button_cordsy+7.5))
        WIN.blit(get_code_button, (get_code_button_cordsx+38, get_code_button_cordsy+7.5))
        #WIN.blit(how_to_play_button_Black, (how_to_play_button_cordsx+130, how_to_play_button_cordsy+20))
        #WIN.blit(how_to_play_button_White, (how_to_play_button_cordsx+130, how_to_play_button_cordsy+20))
        WIN.blit(made_by_Nisk1, (710, 460))
        #}

        main_menu_how_to_play_img() #display the image of poker game(how to play)
        pygame.display.update() # updates the frames of the menu
    pygame.quit()

def continue_main_menu(): #creates continue_menu window
    back_to_main_menu_button = button_font.render('Back' , True , Black) #creates back to main menu button (text)
    
    run=True
    clock=pygame.time.Clock()
    while run:
        clock.tick(FPS60) #makes sure loop runs 60 times per second
        #print(pygame.mouse.get_pos())
        for ev in pygame.event.get():

            if ev.type == pygame.QUIT: #checks if users closes program
                run=False

            if ev.type == pygame.MOUSEBUTTONDOWN: #if the mouse is clicked on the button the main_game is opend
                if back_to_main_menu_button_cordsx <= mouse[0] <= back_to_main_menu_button_cordsx+button_sizex and back_to_main_menu_button_cordsy <= mouse[1] <= back_to_main_menu_button_cordsy+button_sizey:
                    main_main_menu()

        mouse = pygame.mouse.get_pos() #gets position of the mouse

        #back_to_main_menu_button{
        if back_to_main_menu_button_cordsx <= mouse[0] <= back_to_main_menu_button_cordsx+button_sizex and back_to_main_menu_button_cordsy <= mouse[1] <= back_to_main_menu_button_cordsy+button_sizey: #<--- clicked
            pygame.draw.rect(WIN,Button_clicked_colour,[back_to_main_menu_button_cordsx, back_to_main_menu_button_cordsy, button_sizex, button_sizey])
        else:
            pygame.draw.rect(WIN,Button_not_clicked_colour,[back_to_main_menu_button_cordsx, back_to_main_menu_button_cordsy, button_sizex, button_sizey])
        #}

        WIN.blit(back_to_main_menu_button, (back_to_main_menu_button_cordsx+5, back_to_main_menu_button_cordsy+7.5)) #combining our text with rectangles (creating button)
        pygame.display.update() # updates the frames of the window
    pygame.quit()

def settings_main_menu(): #creates settings_menu window
    back_to_main_menu_button = button_font.render('Back' , True , Black) #creates back to main menu button (text)

    run=True
    clock=pygame.time.Clock()
    while run:
        clock.tick(FPS60) #makes sure loop runs 60 times per second
        #print(pygame.mouse.get_pos())
        for ev in pygame.event.get():

            if ev.type == pygame.QUIT: #checks if users closes program
                run=False

            if ev.type == pygame.MOUSEBUTTONDOWN: #if the mouse is clicked on the button the main_game is opend
                if back_to_main_menu_button_cordsx <= mouse[0] <= back_to_main_menu_button_cordsx+button_sizex and back_to_main_menu_button_cordsy <= mouse[1] <= back_to_main_menu_button_cordsy+button_sizey:
                    main_main_menu()

        mouse = pygame.mouse.get_pos() #gets position of the mouse

        #back_to_main_menu_button{
        if back_to_main_menu_button_cordsx <= mouse[0] <= back_to_main_menu_button_cordsx+button_sizex and back_to_main_menu_button_cordsy <= mouse[1] <= back_to_main_menu_button_cordsy+button_sizey: #<--- clicked
            pygame.draw.rect(WIN,Button_clicked_colour,[back_to_main_menu_button_cordsx, back_to_main_menu_button_cordsy, button_sizex, button_sizey])
        else:
            pygame.draw.rect(WIN,Button_not_clicked_colour,[back_to_main_menu_button_cordsx, back_to_main_menu_button_cordsy, button_sizex, button_sizey])
        #}

        WIN.blit(back_to_main_menu_button, (back_to_main_menu_button_cordsx+5, back_to_main_menu_button_cordsy+7.5)) #combining our text with rectangles (creating button)
        pygame.display.update() # updates the frames of the window
    pygame.quit()

def info_main_menu(): #creates info_menu window
    back_to_main_menu_button = button_font.render('Back' , True , Black) #creates back to main menu button (text)

    run=True
    clock=pygame.time.Clock()
    while run:
        clock.tick(FPS60) #makes sure loop runs 60 times per second
        #print(pygame.mouse.get_pos())
        for ev in pygame.event.get():

            if ev.type == pygame.QUIT: #checks if users closes program
                run=False

            if ev.type == pygame.MOUSEBUTTONDOWN: #if the mouse is clicked on the button the main_game is opend
                if back_to_main_menu_button_cordsx <= mouse[0] <= back_to_main_menu_button_cordsx+button_sizex and back_to_main_menu_button_cordsy <= mouse[1] <= back_to_main_menu_button_cordsy+button_sizey:
                    main_main_menu()

        mouse = pygame.mouse.get_pos() #gets position of the mouse

        #back_to_main_menu_button{
        if back_to_main_menu_button_cordsx <= mouse[0] <= back_to_main_menu_button_cordsx+button_sizex and back_to_main_menu_button_cordsy <= mouse[1] <= back_to_main_menu_button_cordsy+button_sizey: #<--- clicked
            pygame.draw.rect(WIN,Button_clicked_colour,[back_to_main_menu_button_cordsx, back_to_main_menu_button_cordsy, button_sizex, button_sizey])
        else:
            pygame.draw.rect(WIN,Button_not_clicked_colour,[back_to_main_menu_button_cordsx, back_to_main_menu_button_cordsy, button_sizex, button_sizey])
        #}

        WIN.blit(back_to_main_menu_button, (back_to_main_menu_button_cordsx+5, back_to_main_menu_button_cordsy+7.5)) #combining our text with rectangles (creating button)
        pygame.display.update() # updates the frames of the window
    pygame.quit()

def code_main_menu(): #opens my github profile when button(code) is clicked <--------(not working!) console output:(sh: 1: https://github.com/Nisk1: not found)
    try:
        os.system("https://github.com/Nisk1")
        print("a")
    except:  
        webbrowser.open_new_tab("https://github.com/Nisk1")
        print("b")

def how_to_play_main_menu(): #creates how_to_play_menu window
    back_to_main_menu_button = button_font.render('Back' , True , Black) #creates back to main menu button (text)

    run=True
    clock=pygame.time.Clock()
    while run:
        clock.tick(FPS60) #makes sure loop runs 60 times per second
        #print(pygame.mouse.get_pos())
        for ev in pygame.event.get():

            if ev.type == pygame.QUIT: #checks if users closes program
                run=False

            if ev.type == pygame.MOUSEBUTTONDOWN: #if the mouse is clicked on the button the main_game is opend
                if back_to_main_menu_button_cordsx <= mouse[0] <= back_to_main_menu_button_cordsx+button_sizex and back_to_main_menu_button_cordsy <= mouse[1] <= back_to_main_menu_button_cordsy+button_sizey:
                    main_main_menu()

        mouse = pygame.mouse.get_pos() #gets position of the mouse

        #back_to_main_menu_button{
        if back_to_main_menu_button_cordsx <= mouse[0] <= back_to_main_menu_button_cordsx+button_sizex and back_to_main_menu_button_cordsy <= mouse[1] <= back_to_main_menu_button_cordsy+button_sizey: #<--- clicked
            pygame.draw.rect(WIN,Button_clicked_colour,[back_to_main_menu_button_cordsx, back_to_main_menu_button_cordsy, button_sizex, button_sizey])
        else:
            pygame.draw.rect(WIN,Button_not_clicked_colour,[back_to_main_menu_button_cordsx, back_to_main_menu_button_cordsy, button_sizex, button_sizey])
        #}

        WIN.blit(back_to_main_menu_button, (back_to_main_menu_button_cordsx+5, back_to_main_menu_button_cordsy+7.5)) #combining our text with rectangles (creating button)
        pygame.display.update() # updates the frames of the game
    pygame.quit()
#}



#{ <cards>
def middle_cards(): #assigns card to each middle card slot
    print("len(print(middle_cards)): ",len(all_middle_cards))
    print("middle_cards: ",all_middle_cards)
    for i in range (len(all_middle_cards)):
        if i == 0:
            slot=middle_card_slot0
        elif i == 1:
            slot=middle_card_slot1
        elif i == 2:
            slot=middle_card_slot2
        elif i == 3:
            slot=middle_card_slot3
        elif i == 4:
            slot=middle_card_slot4

        z=random.randint(0, len(available_cards)-1)
        slot.append(available_cards[z])
        available_cards.remove(available_cards[z])
        i+=1
        print("len(print(middle_cards)): ",len(all_middle_cards))
        print("middle_cards: ",all_middle_cards)

def give_cards_to_players(): #assigns 2 cards to each player
    for i in range (len(all_players)):
        if i == 0:
            player=player0
        elif i == 1:
            player=player1
        elif i == 2:
            player=player2
        elif i == 3:
            player=player3
        elif i == 4:
            player=player4
        elif i == 5:
            player=player5
        elif i == 6:
            player=player6
        elif i == 7:
            player=player7

        for i in range(2):
            z=random.randint(0, len(available_cards)-1)
            player.append(available_cards[z])
            available_cards.remove(available_cards[z])
        i+=1

class Middle_cards: #creates class for middle cards (fill) and (outlines)
    def __init__(self, left):
        global middle_card_size
        self.left = left
        left=int(left)
        left=left*50
        middle_card_size=(335+left, 222.5), (30, 45)

    def middle_cards(self): #creates White fill for middle cards
        pygame.draw.rect(WIN, White, middle_card_size)

    def middle_cards_outline(self): #creates Black outlines for middle cards
        pygame.draw.lines(WIN, Black, True, ((335, 222.5), (365, 222.5), (365, 267.5), (335, 267.5)), width=5)#outline 0
        pygame.draw.lines(WIN, Black, True, ((385, 222.5), (415, 222.5), (415, 267.5), (385, 267.5)), width=5)#outline 1
        pygame.draw.lines(WIN, Black, True, ((435, 222.5), (465, 222.5), (465, 267.5), (435, 267.5)), width=5)#outline 2
        pygame.draw.lines(WIN, Black, True, ((485, 222.5), (515, 222.5), (515, 267.5), (485, 267.5)), width=5)#outline 3
        pygame.draw.lines(WIN, Black, True, ((535, 222.5), (565, 222.5), (565, 267.5), (535, 267.5)), width=5)#outline 4

class Players_cards_outline: #creates class for player's cards (fill) and (outlines)
    def __init__(self):
        pass

    def user_outline(self, colour):
        x=415
        y=377.5

        card_size=((x, y), (30, 45)) 
        card_size2=((x+40, y), (30, 45))
        pygame.draw.rect(WIN, White, card_size)
        pygame.draw.rect(WIN, White, card_size2)

        pygame.draw.lines(WIN, colour, True, ((x, y), (x+30, y), (x+30, y+45), (x, y+45)), width=5)
        pygame.draw.lines(WIN, colour, True, ((x+40, y), (x+70, y), (x+70, y+45), (x+40, y+45)), width=5)

    def player1_outline(self, colour):
        x=260
        y=350
        
        card_size=((x, y), (30, 45)) 
        card_size2=((x+40, y), (30, 45))
        pygame.draw.rect(WIN, White, card_size)
        pygame.draw.rect(WIN, White, card_size2)
        
        pygame.draw.lines(WIN, colour, True, ((x, y), (x+30, y), (x+30, y+45), (x, y+45)), width=5)
        pygame.draw.lines(WIN, colour, True, ((x+40, y), (x+70, y), (x+70, y+45), (x+40, y+45)), width=5)

    def player2_outline(self, colour):
        x=162.5
        y=222.5
        
        card_size=((x, y), (30, 45)) 
        card_size2=((x+40, y), (30, 45))
        pygame.draw.rect(WIN, White, card_size)
        pygame.draw.rect(WIN, White, card_size2)
        
        pygame.draw.lines(WIN, colour, True, ((x, y), (x+30, y), (x+30, y+45), (x, y+45)), width=5)
        pygame.draw.lines(WIN, colour, True, ((x+40, y), (x+70, y), (x+70, y+45), (x+40, y+45)), width=5)

    def player3_outline(self, colour):
        x=260
        y=110
        
        card_size=((x, y), (30, 45)) 
        card_size2=((x+40, y), (30, 45))
        pygame.draw.rect(WIN, White, card_size)
        pygame.draw.rect(WIN, White, card_size2)
        
        pygame.draw.lines(WIN, colour, True, ((x, y), (x+30, y), (x+30, y+45), (x, y+45)), width=5)
        pygame.draw.lines(WIN, colour, True, ((x+40, y), (x+70, y), (x+70, y+45), (x+40, y+45)), width=5)

    def player4_outline(self, colour):
        x=415
        y=72.5
        
        card_size=((x, y), (30, 45)) 
        card_size2=((x+40, y), (30, 45))
        pygame.draw.rect(WIN, White, card_size)
        pygame.draw.rect(WIN, White, card_size2)
        
        pygame.draw.lines(WIN, colour, True, ((x, y), (x+30, y), (x+30, y+45), (x, y+45)), width=5)
        pygame.draw.lines(WIN, colour, True, ((x+40, y), (x+70, y), (x+70, y+45), (x+40, y+45)), width=5)

    def player5_outline(self, colour):
        x=570
        y=110
        
        card_size=((x, y), (30, 45)) 
        card_size2=((x+40, y), (30, 45))
        pygame.draw.rect(WIN, White, card_size)
        pygame.draw.rect(WIN, White, card_size2)
        
        pygame.draw.lines(WIN, colour, True, ((x, y), (x+30, y), (x+30, y+45), (x, y+45)), width=5)
        pygame.draw.lines(WIN, colour, True, ((x+40, y), (x+70, y), (x+70, y+45), (x+40, y+45)), width=5)

    def player6_outline(self, colour):
        x=670
        y=222.5
        
        card_size=((x, y), (30, 45)) 
        card_size2=((x+40, y), (30, 45))
        pygame.draw.rect(WIN, White, card_size)
        pygame.draw.rect(WIN, White, card_size2)
        
        pygame.draw.lines(WIN, colour, True, ((x, y), (x+30, y), (x+30, y+45), (x, y+45)), width=5)
        pygame.draw.lines(WIN, colour, True, ((x+40, y), (x+70, y), (x+70, y+45), (x+40, y+45)), width=5)

    def player7_outline(self, colour):
        x=570
        y=350
        
        card_size=((x, y), (30, 45)) 
        card_size2=((x+40, y), (30, 45))
        pygame.draw.rect(WIN, White, card_size)
        pygame.draw.rect(WIN, White, card_size2)
        
        pygame.draw.lines(WIN, colour, True, ((x, y), (x+30, y), (x+30, y+45), (x, y+45)), width=5)
        pygame.draw.lines(WIN, colour, True, ((x+40, y), (x+70, y), (x+70, y+45), (x+40, y+45)), width=5)

class ShowCards(): #determines whether to show player's cards
    def __init__(self):
        pass

    #def __init__(self, x):
    #    self.x=x

    def show_cards_user(self):
        
        player0_card_1 = cards_font.render(player0[0], True, (0,0,0)) #show's player first card
        WIN.blit(player0_card_1, (418,390))
        player0_card_2 = cards_font.render(player0[1], True, (0,0,0)) #show's player second card
        WIN.blit(player0_card_2, (458,390))   

    def show_cards_rest(slef):
        pass

def show_middle_cards_first(): #shows first three middle cards
    global show_middle_cards_2
    show_middle_cards_2 = True

    card0=Middle_cards(0)
    card0.middle_cards()

    card1=Middle_cards(1)
    card1.middle_cards()

    card2=Middle_cards(2)
    card2.middle_cards()

    middle_cards_to_show.append(middle_card_slot0)
    middle_cards_to_show.append(middle_card_slot1)
    middle_cards_to_show.append(middle_card_slot2)
    #print(middle_cards_to_show)

    #print("middle_cards_to_show: ",middle_cards_to_show) #<--------------inne nie jes to all_middle_cards
    for i in middle_cards_to_show:
        if middle_card_slot0 in middle_cards_to_show:
            middle_card_slot0_name = cards_font.render(middle_card_slot0[0], True, (0,0,0))
            WIN.blit(middle_card_slot0_name, (340,235))
            
        if middle_card_slot1 in middle_cards_to_show:
            middle_card_slot1_name = cards_font.render(middle_card_slot1[0], True, (0,0,0))
            WIN.blit(middle_card_slot1_name, (390,235))

        if middle_card_slot2 in middle_cards_to_show:
            middle_card_slot2_name = cards_font.render(middle_card_slot2[0], True, (0,0,0))
            WIN.blit(middle_card_slot2_name, (440,235))

def show_middle_cards_middle(): #shows fourth middle card
    global show_middle_cards_3
    show_middle_cards_3 = True

    card3=Middle_cards(3)
    card3.middle_cards()

    middle_cards_to_show.append(middle_card_slot3)

    for i in middle_cards_to_show:
        if middle_card_slot3 in middle_cards_to_show:
            middle_card_slot3_name = cards_font.render(middle_card_slot3[0], True, (0,0,0))
            WIN.blit(middle_card_slot3_name, (490,235))

def show_middle_cards_last(): #shows last middle card
    card4=Middle_cards(4)
    card4.middle_cards()

    middle_cards_to_show.append(middle_card_slot4)

    for i in middle_cards_to_show:
        if middle_card_slot4 in middle_cards_to_show:
            middle_card_slot4_name = cards_font.render(middle_card_slot4[0], True, (0,0,0))
            WIN.blit(middle_card_slot4_name, (540,235))

def players_cards_outlines_all(): #creates cards outlines for all players
    player0=Players_cards_outline()
    player0.user_outline(Blue)

    player1=Players_cards_outline()
    player1.player1_outline(Red)

    player2=Players_cards_outline()
    player2.player2_outline(Red)

    player3=Players_cards_outline()
    player3.player3_outline(Red)

    player4=Players_cards_outline()
    player4.player4_outline(Red)

    player5=Players_cards_outline()
    player5.player5_outline(Red)

    player6=Players_cards_outline()
    player6.player6_outline(Red)

    player7=Players_cards_outline()
    player7.player7_outline(Red)
#}



#{ <players>
def queue_order(): #generates order in which players will play the game
    #print(new_list)
    for key, value in Small_dic.items():
        new_list.append(key)
        queue.append(key)
        order.remove(key)

    for key, value in Big_dic.items():
        new_list.append(key)
        queue.append(key)
        order.remove(key)

    #print(new_list[0]<new_list[1])
    if new_list[0]<new_list[1]:
        y=new_list[0]
        #print('new_list[0]',y)

    if new_list[0]>new_list[1]:
        y=new_list[1]
        #print('new_list[1]',y)

    #print(new_list[0]>new_list[1])

    #print("new_list",new_list)
    #print("")

    removed_list=[]
    #print("Player0">"Player1")
    x=0
    for i in order:
        if order[x]<y:
            removed_list.append(order[x])
        else:
            queue.append(order[x])
        x+=1
    x=0
    for i in removed_list:
        queue.append(removed_list[x])  
        x+=1
    print("Queue: ",queue)

def player_names(): #generates player names
    player0_name = names_font.render("You", True, (Blue))
    WIN.blit(player0_name, (432.5,430))

    player1_name = names_font.render("Player1", True, (Red))
    WIN.blit(player1_name, (262.5,400))
    
    player2_name = names_font.render("Player2", True, (Red))
    #WIN.blit(player2_name, (164.5,200))
    WIN.blit(player2_name, (140,200))
    
    player3_name = names_font.render("Player3", True, (Red))
    WIN.blit(player3_name, (262.5,88))
    
    player4_name = names_font.render("Player4", True, (Red))
    WIN.blit(player4_name, (418,50))
    
    player5_name = names_font.render("Player5", True, (Red))
    WIN.blit(player5_name, (572.5,88))
    
    player6_name = names_font.render("Player6", True, (Red))
    #WIN.blit(player6_name, (672.5,202))
    WIN.blit(player6_name, (700,202))
    
    player7_name = names_font.render("Player7", True, (Red))
    WIN.blit(player7_name, (572.5,400)) 

def player_queue_indicator(): #creates a queue indicator (changes (current's player in queue) name colour to yellow)
    i=0
    #print("i",i)
    #print(current_player_in_queue_list)
    if current_player_in_queue_list[i] == "Player0":
        player0_name = names_font.render("You", True, (Yellow))
        WIN.blit(player0_name, (432.5,430))

    elif current_player_in_queue_list[i] == "Player1":
        player1_name = names_font.render("Player1", True, (Yellow))
        WIN.blit(player1_name, (262.5,400))

    elif current_player_in_queue_list[i] == "Player2":
        player2_name = names_font.render("Player2", True, (Yellow))
        #WIN.blit(player2_name, (164.5,200))
        WIN.blit(player2_name, (140,200))

    elif current_player_in_queue_list[i] == "Player3":
        player3_name = names_font.render("Player3", True, (Yellow))
        WIN.blit(player3_name, (262.5,88))

    elif current_player_in_queue_list[i] == "Player4":
        player4_name = names_font.render("Player4", True, (Yellow))
        WIN.blit(player4_name, (418,50))

    elif current_player_in_queue_list[i] == "Player5":
        player5_name = names_font.render("Player5", True, (Yellow))
        WIN.blit(player5_name, (572.5,88))

    elif current_player_in_queue_list[i] == "Player6":
        player6_name = names_font.render("Player6", True, (Yellow))
        #WIN.blit(player6_name, (672.5,202))
        WIN.blit(player6_name, (700,202))

    elif current_player_in_queue_list[i] == "Player7":
        player7_name = names_font.render("Player7", True, (Yellow))
        WIN.blit(player7_name, (572.5,400))

def current_player_in_queue(index_current_player): #defines which player is currently first in queue
    current_player_in_queue_list.append(queue[index_current_player])

    if len(current_player_in_queue_list)>1:
        current_player_in_queue_list.remove(current_player_in_queue_list[0])
    print("Current_player_in_queue_list: ",current_player_in_queue_list)

def pass_player_indication(): #creates a pass player indicator (changes (passed player's) name colour to white)
    #while True:
        for i in passed_players:

            if i=="Player0":
                player0_name = names_font.render("You", True, (White))
                WIN.blit(player0_name, (432.5,430))

            if i=="Player1":
                player1_name = names_font.render("Player1", True, (White))
                WIN.blit(player1_name, (262.5,400))

            if i=="Player2":
                player2_name = names_font.render("Player2", True, (White))
                #WIN.blit(player2_name, (164.5,200))
                WIN.blit(player2_name, (140,200))

            if i=="Player3":
                player3_name = names_font.render("Player3", True, (White))
                WIN.blit(player3_name, (262.5,88))

            if i=="Player4":
                player4_name = names_font.render("Player4", True, (White))
                WIN.blit(player4_name, (418,50))

            if i=="Player5":
                player5_name = names_font.render("Player5", True, (White))
                WIN.blit(player5_name, (572.5,88))

            if i=="Player6":
                player6_name = names_font.render("Player6", True, (White))
                #WIN.blit(player6_name, (672.5,202))
                WIN.blit(player6_name, (700,202))

            if i=="Player7":
                player7_name = names_font.render("Player7", True, (White))
                WIN.blit(player7_name, (572.5,400))

def pass_player_indication_better(): #creates a better pass player indicator (creates line that is passing through passed player's name)
        line_x=100 
        line_y=3
    #while True:
        for i in passed_players:

            if i=="Player0":
                pygame.draw.rect(WIN, Red, ((400,438.5),(line_x, line_y)), width=0)
                #WIN.blit(player0_name, (432.5,430))

            if i=="Player1":
                pygame.draw.rect(WIN, Red, ((245,409),(line_x, line_y)), width=0)
                #WIN.blit(player1_name, (262.5,400))

            if i=="Player2":
                pygame.draw.rect(WIN, Red, ((125,209),(line_x, line_y)), width=0)
                #WIN.blit(player2_name, (140,200))

            if i=="Player3":
                pygame.draw.rect(WIN, Red, ((245,97.5),(line_x, line_y)), width=0)
                #WIN.blit(player3_name, (262.5,88))

            if i=="Player4":
                pygame.draw.rect(WIN, Red, ((400,60),(line_x, line_y)), width=0)
                #WIN.blit(player4_name, (418,50))

            if i=="Player5":
                pygame.draw.rect(WIN, Red, ((555,97.5),(line_x, line_y)), width=0)
                #WIN.blit(player5_name, (572.5,88))

            if i=="Player6":
                pygame.draw.rect(WIN, Red, ((680,211),(line_x, line_y)), width=0)
                #WIN.blit(player6_name, (672.5,202))
                #WIN.blit(player6_name, (700,202))

            if i=="Player7":
                pygame.draw.rect(WIN, Red, ((555,409),(line_x, line_y)), width=0)

def player_random_action(player): #makes computer (other players) choose between (pass, check and bid) (it's gonna be changed later (so its not random.choice()))
    global random_money_to_bid
    global playerup
    playerup=True
    random_action=random.choice(choices)
    print("passed_players: ",passed_players)
    print("IN game players: ",queue)
    print("last_to_check: ",last_to_check)
    print("money_to_check: ", money_to_check," for ", current_player_in_queue_list[0])
    if random_action=="pass":
        print("passsssssssssssssss ",queue[player])
        #print(queue[player])
        passed_players.append(queue[player])

        queue.remove(queue[player])
        playerup=False 

    if random_action=="check":
        print("checkkkkkkkkkkkkk ",queue[player])
        for key, value in Players_money_dic.items():
            if current_player_in_queue_list[0]==key:
                Players_money_dic[key]=Players_money_dic[key]-money_to_check
    
    if random_action=="bid":
        random_money_to_bid=random.randint(1, 10)
        print("bidddddddddddddd ",queue[player])
        last_to_check.append(queue[player])
        if len(last_to_check)>1:
            last_to_check.remove(last_to_check[0])
        for key, value in Players_money_dic.items():
            if current_player_in_queue_list[0]==key:
                Players_money_dic[key]=Players_money_dic[key]-(random_money_to_bid+money_to_check)
#}



#{ <buttons>
def make_players_buttons(): #defines players that are gonna be (button), (small_blind) and (big_blind)
    c=random.randint(0, len(all_players)-1)

    if c == 0:
        Button_dic["Player0"]=True
        Small_dic["Player1"]=True
        Big_dic["Player2"]=True

    elif c == 1:
        Button_dic["Player1"]=True
        Small_dic["Player2"]=True
        Big_dic["Player3"]=True

    elif c == 2:
        Button_dic["Player2"]=True
        Small_dic["Player3"]=True
        Big_dic["Player4"]=True

    elif c == 3:
        Button_dic["Player3"]=True
        Small_dic["Player4"]=True
        Big_dic["Player5"]=True

    elif c == 4:
        Button_dic["Player4"]=True
        Small_dic["Player5"]=True
        Big_dic["Player6"]=True

    elif c == 5:
        Button_dic["Player5"]=True
        Small_dic["Player6"]=True
        Big_dic["Player7"]=True

    elif c == 6:
        Button_dic["Player6"]=True
        Small_dic["Player7"]=True
        Big_dic["Player0"]=True

    elif c == 7:
        Button_dic["Player7"]=True
        Small_dic["Player0"]=True
        Big_dic["Player1"]=True

def show_players_buttons(): #shows who's (button), (small_blind) and (big_blind)

    for key, value in Button_dic.items():
        #print(key)
        #print(value)
        if key == "Player0":
            player0 = player_spaces_font.render("Button", True, (Black))
            WIN.blit(player0, (Player0_space))

        elif key == "Player1":
            player1 = player_spaces_font.render("Button", True, (Black))
            WIN.blit(player1, (Player1_space))

        elif key == "Player2":
            player2 = player_spaces_font.render("Button", True, (Black))
            WIN.blit(player2, (Player2_space))
        
        elif key == "Player3":
            player3 = player_spaces_font.render("Button", True, (Black))
            WIN.blit(player3, (Player3_space))

        elif key == "Player4":
            player4 = player_spaces_font.render("Button", True, (Black))
            WIN.blit(player4, (Player4_space))

        elif key == "Player5":
            player5 = player_spaces_font.render("Button", True, (Black))
            WIN.blit(player5, (Player5_space))

        elif key == "Player6":
            player6 = player_spaces_font.render("Button", True, (Black))
            WIN.blit(player6, (Player6_space))
        
        elif key == "Player7":
            player7 = player_spaces_font.render("Button", True, (Black))
            WIN.blit(player7, (Player7_space))

    for key, value in Small_dic.items():
        #print(key)
        #print(value)
        if key == "Player0":
            player0 = player_spaces_font.render("Small", True, (Black))
            WIN.blit(player0, (Player0_space))

        elif key == "Player1":
            player1 = player_spaces_font.render("Small", True, (Black))
            WIN.blit(player1, (Player1_space))

        elif key == "Player2":
            player2 = player_spaces_font.render("Small", True, (Black))
            WIN.blit(player2, (Player2_space))
        
        elif key == "Player3":
            player3 = player_spaces_font.render("Small", True, (Black))
            WIN.blit(player3, (Player3_space))

        elif key == "Player4":
            player4 = player_spaces_font.render("Small", True, (Black))
            WIN.blit(player4, (Player4_space))

        elif key == "Player5":
            player5 = player_spaces_font.render("Small", True, (Black))
            WIN.blit(player5, (Player5_space))

        elif key == "Player6":
            player6 = player_spaces_font.render("Small", True, (Black))
            WIN.blit(player6, (Player6_space))
        
        elif key == "Player7":
            player7 = player_spaces_font.render("Small", True, (Black))
            WIN.blit(player7, (Player7_space))

    for key, value in Big_dic.items():
        #print(key)
        #print(value)
        if key == "Player0":
            player0 = player_spaces_font.render("Big", True, (Black))
            WIN.blit(player0, (Player0_space))

        elif key == "Player1":
            player1 = player_spaces_font.render("Big", True, (Black))
            WIN.blit(player1, (Player1_space))

        elif key == "Player2":
            player2 = player_spaces_font.render("Big", True, (Black))
            WIN.blit(player2, (Player2_space))
        
        elif key == "Player3":
            player3 = player_spaces_font.render("Big", True, (Black))
            WIN.blit(player3, (Player3_space))

        elif key == "Player4":
            player4 = player_spaces_font.render("Big", True, (Black))
            WIN.blit(player4, (Player4_space))

        elif key == "Player5":
            player5 = player_spaces_font.render("Big", True, (Black))
            WIN.blit(player5, (Player5_space))

        elif key == "Player6":
            player6 = player_spaces_font.render("Big", True, (Black))
            WIN.blit(player6, (Player6_space))
        
        elif key == "Player7":
            player7 = player_spaces_font.render("Big", True, (Black))
            WIN.blit(player7, (Player7_space))
#}



#{ <money>
def Players_money_dic_in_order(): #creates a dictionary with players in order
    c=0
    for key, value in Players_money_dic.items():
        player_for_dic=queue[c]
        Players_money_dic_queue[player_for_dic]=value
        c+=1
    print("Money Queue: ",Players_money_dic_queue)

def wpisowe(player): #creates entry fee
    wpisowe=5
    for key, value in Players_money_dic.items():

        if queue[player]==key:
            Players_money_dic[key]=Players_money_dic[key]-wpisowe
            #print("asdasd",queue[7])
            #print("current_player_in_queue_list[0]:  ",current_player_in_queue_list[0])
            #print("queue[len(queue)-1:  ", len(queue)-1)
        if player == 8:
            #print("IFIFIFIF stop = true")
            break

    print("Wpisowe: ",Players_money_dic)

def blinds_money(): #creates blinds_money (money that is given by (player(small_blind)) and  player(big_blind)) (it's gonna be changed later (so its not random.randint()))
    x=random.randint(1, 10)
    if len(blinds_money_value)<1:
        blinds_money_value.append(x)
    small_b=blinds_money_value[0]
    big_b=2*blinds_money_value[0]
    #print("small_b: ",small_b)
    #print("big_b: ",big_b)
    for key, value in Small_dic.items():
        #print("kyras",key)
        if key in Players_money_dic:
            if current_player_in_queue_list[0] == key:
                #print("ahoooooooooooooj")
                #print(Players_money_dic)
                Players_money_dic[key]=Players_money_dic[key]-small_b
                #print(Players_money_dic)

    time_sleep_random=random.randint(1,3)
    time.sleep(time_sleep_random)

    for key, value in Big_dic.items():
        #print("kyras",key)
        if key in Players_money_dic:
            if current_player_in_queue_list[0] == key:
                #print("ahoooooooooooooj")
                #print(Players_money_dic)
                Players_money_dic[key]=Players_money_dic[key]-big_b
                #print(Players_money_dic)
    print("Blinds: ",Players_money_dic)

def money_queue(): #for each player prints(value, key, low_money_to_check, money_to_check) (chat only)
    #output:
        #value  100
        #key  Player0
        #low_money_to_check  100 (its lowest amount of money that is owned by any player)
        #money_to_check  0 (its amount of money that has to be put inside pool in order to play game)

    high_money_to_check = 0
    for key, value in Players_money_dic.items():
        if value > high_money_to_check:
            high_money_to_check=value
    print("Highest value: ",high_money_to_check)
    low_money_to_check=high_money_to_check

    for key, value in Players_money_dic.items():
        if value < low_money_to_check:
            low_money_to_check=value
    print("Lowest value: ",low_money_to_check)

    for key, value in Players_money_dic.items():
        print("\n")
        print("value ",value)
        print("key ",key)
        print("low_money_to_check ", low_money_to_check)
        money_to_check=value-low_money_to_check
        print("money_to_check ", money_to_check)

def show_money():  #shows amount of money thats owned by every player
    for key, value in Players_money_dic.items():
        money_to_show=value
        #print("money_to_show: ",money_to_show)
        #print("key: ",key)
        #print("value: ",value)

        if key == "Player0":
            player0_money = Players_money_fonts.render(str(value), True, (Yellow))
            WIN.blit(player0_money, (Player0_money_space))

        elif key == "Player1":
            player1_money = Players_money_fonts.render(str(value), True, (Yellow))
            WIN.blit(player1_money, (Player1_money_space))

        elif key == "Player2":
            player2_money = Players_money_fonts.render(str(value), True, (Yellow))
            WIN.blit(player2_money, (Player2_money_space))
        
        elif key == "Player3":
            player3_money = Players_money_fonts.render(str(value), True, (Yellow))
            WIN.blit(player3_money, (Player3_money_space))

        elif key == "Player4":
            player4_money = Players_money_fonts.render(str(value), True, (Yellow))
            WIN.blit(player4_money, (Player4_money_space))

        elif key == "Player5":
            player5_money = Players_money_fonts.render(str(value), True, (Yellow))
            WIN.blit(player5_money, (Player5_money_space))

        elif key == "Player6":
            player6_money = Players_money_fonts.render(str(value), True, (Yellow))
            WIN.blit(player6_money, (Player6_money_space))
        
        elif key == "Player7":
            player7_money = Players_money_fonts.render(str(value), True, (Yellow))
            WIN.blit(player7_money, (Player7_money_space))

def money_taken_from_player(): #shows amount of money taken from player when (check/bid) <--------------------------------(not working!)
    if current_player_in_queue_list[0] not in passed_players:

        if current_player_in_queue_list[0] in last_to_check:
            money_to_check_taken=("-"+str(money_to_check+random_money_to_bid))

        else:
            money_to_check_taken=("-"+str(money_to_check))
    
        if current_player_in_queue_list[0] == "Player0":
            player0_money_taken = Players_money_fonts.render(str(money_to_check_taken), True, (Yellow))
            WIN.blit(player0_money_taken, (485, 450))
    
        if current_player_in_queue_list[0] == "Player1":
            player1_money_taken = Players_money_fonts.render(str(money_to_check_taken), True, (Yellow))
            WIN.blit(player1_money_taken, (185, 345))
    
        if current_player_in_queue_list[0] == "Player2":
            player2_money_taken = Players_money_fonts.render(str(money_to_check_taken), True, (Yellow))
            WIN.blit(player2_money_taken, (90, 190))
    
        if current_player_in_queue_list[0] == "Player3":
            player3_money_taken = Players_money_fonts.render(str(money_to_check_taken), True, (Yellow))
            WIN.blit(player3_money_taken, (185, 80))
    
        if current_player_in_queue_list[0] == "Player4":
            player4_money_taken = Players_money_fonts.render(str(money_to_check_taken), True, (Yellow))
            WIN.blit(player4_money_taken, (375, 15))
    
        if current_player_in_queue_list[0] == "Player5":
            player5_money_taken = Players_money_fonts.render(str(money_to_check_taken), True, (Yellow))
            WIN.blit(player5_money_taken, (675, 80))
    
        if current_player_in_queue_list[0] == "Player6":
            player6_money_taken = Players_money_fonts.render(str(money_to_check_taken), True, (Yellow))
            WIN.blit(player6_money_taken, (775, 190))
    
        if current_player_in_queue_list[0] == "Player7":
            player7_money_taken = Players_money_fonts.render(str(money_to_check_taken), True, (Yellow))
            WIN.blit(player7_money_taken, (675, 345))

def money_given_to_the_pool(): #shows amount of money that is given to the pool after player (checks/bids)
    money_to_check_given=("+"+str(money_to_check))

    money_given = Players_money_fonts.render(str(money_to_check_given), True, (Yellow))
    WIN.blit(money_given, (475, 295))

def show_pool_sum(): #shows amount of money that is inside a pool  <------------------------------------------------------(not working!)
    money_in_pool=("Pool: "+str(pool_sum))

    pool_sum_to_show = Players_money_fonts.render(str(money_in_pool), True, (Yellow))
    WIN.blit(pool_sum_to_show, (400, 295))

def money_to_check_func(): #defines money_to_check for current player in a queue
    global money_to_check
    high_money_to_check = 0
    for key, value in Players_money_dic.items():
        if value > high_money_to_check:
            high_money_to_check=value
    #print("Highest value: ",high_money_to_check)
    low_money_to_check=high_money_to_check

    for key, value in Players_money_dic.items():
        if value < low_money_to_check:
            low_money_to_check=value
    #print("Lowest value: ",low_money_to_check)

    for key, value in Players_money_dic.items():
        #print("\n")
        #print("value ",value)
        #print("key ",key)
        #print("low_money_to_check ", low_money_to_check)
        if key == current_player_in_queue_list[0]:
            money_to_check=value-low_money_to_check

def check_for_last_to_check(): #checks if any player made bid in current queue if not shows middle cards
    
    if current_player_in_queue_list[0] == last_to_check[0] and money_to_check == 0:
        print("checkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk")
        global show_mid_cards_all
        global check_count

        check_count+=1
        show_mid_cards_all=True
        time.sleep(5)
#}



#{ <main>
def mid_game_turn(): 
    print("b1") 
    turn_over = False
    turn_number=1
    player=2
    print(queue[player])
    print("new_threaddddddddddddddddddddddddd")
    while turn_over != True:
        #print(len(queue))
        #print(player)

        while len(queue)==0:
            print("b2") 
            print("konjieccccccccccccccccccccccc")

        if player >= len(queue):
            print("b3") 
            turn_number +=1
            player = 0

        #money_queue()
        print("b3.5")

        current_player_in_queue(player)
        print("b4")

        money_to_check_func()
        print("b5") 
        
        if len(current_player_in_queue_list)>0 and len(last_to_check)>0 and turn_number!=1:
            check_for_last_to_check()
    
        player_random_action(player)
        print("b6")

        time_sleep_random=random.randint(1,3)
        time.sleep(1)
        if playerup == True:
            print("b7") 
            player+=1
        #print("player: ", player)
        print("b0")

def early_game_turn(): 
    turn_over = False
    dowpisowe = True
    doblinds = False
    turn_number=1
    player=0
    #print("doblinds: ", doblinds)
    print("a1")
    while turn_over != True:
        #print("doblinds: ", doblinds)
        if player == 8:
            print("a2")
            turn_number +=1
            player = 0
        current_player_in_queue(player)
        if dowpisowe == True:
            print("a3")
            #print("doblinds: ", doblinds)
            wpisowe(player)
            if player == 7:
                print("a4")
                #print("doblinds: ", doblinds)
                dowpisowe = False
                #print("doblinds: ", doblinds)
                doblinds = True
                #print("doblinds: ", doblinds)
        
        if doblinds == True:
            print("a5")
            blinds_money()
            for key, value in Big_dic.items():
                print("a6")
                #print("kyras",key)
                if key in Players_money_dic:
                    print("a7")
                    if current_player_in_queue_list[0] == key:
                        print("a8")
                        print("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
                        print(queue[player])
                        doblinds = False
                        MID_GAME.start()
                        #-----------------end
                        turn_over = True
                        print("a9")
                        break
                        print("a10")
                        #print(Players_money_dic)
                #if player == 7 and turn_number == 2:
                #    doblinds = False
            #
        if turn_over == False:
            time.sleep(1)
            player+=1
            print("player: ", player)
            print("a0")

MID_GAME = Thread(target=mid_game_turn)
EARLY_GAME = Thread(target=early_game_turn)

def draw_win_not_loop():
    give_cards_to_players()
    make_players_buttons()
    pygame.display.set_caption("Poker~Game") #shows files name
    middle_cards()
    queue_order() #czat only #used <--------
    EARLY_GAME.start() #used <--------
    #MID_GAME.start() #used <-------- (its in EARLY_GAME.start())
    Players_money_dic_in_order() #czat only #used <--------
    money_queue() #czat only #used <--------
    
def draw_window():
    window_fill_colour(Black)
    ellipse()
    pool_rectangle()
    if show_mid_cards_all == True:
        #show_middle_cards()
        show_middle_cards_first()
        if show_middle_cards_2 == True and check_count >= 2:
            show_middle_cards_middle()
        if show_middle_cards_3 == True and check_count >= 3:
            show_middle_cards_last()
    show_money()
    #{errors:
        #money_taken_from_player() 
        #money_given_to_the_pool()
        #show_pool_sum()
    #}

    if check_count == 4: #(end of the game)
        pass

    #print("pool_sum: " + str(pool_sum))

    mid_outline=Middle_cards(0)
    mid_outline.middle_cards_outline()
    players_cards_outlines_all()
    player_names()
    players0_cards=ShowCards()
    players0_cards.show_cards_user()
    #print(pygame.mouse.get_pos())
    show_players_buttons()
    player_queue_indicator()
    pass_player_indication()
    pass_player_indication_better()

def main_game():
    clearscreen()
    clock=pygame.time.Clock()
    run=True
    draw_win_not_loop()
    while run:
        clock.tick(FPS60) 
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run=False
        
        draw_window()
        pygame.display.update()
    pygame.quit()

def main_main_menu():
    clearscreen()
    clock=pygame.time.Clock()
    run=True
    #draw_win_not_loop()
    pygame.display.set_caption("Poker~Main_menu")
    while run:
        clock.tick(FPS60) 
        for event in pygame.event.get(): 
            if event.type == pygame.QUIT:
                run=False

        main_menu_my_img()
        grey_shadow_main_menu(WIN, (0, 0, 0, 200), trapezoid_coordinates)
        all_buttons_main_menu()
        pygame.display.update()
    pygame.quit()

def main_continue_main_menu():
    clearscreen()
    clock=pygame.time.Clock()
    run=True
    window_fill_colour(Black)
    pygame.display.set_caption("Poker~Continue")
    while run:
        clock.tick(FPS60) 
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run=False

        continue_main_menu()
        pygame.display.update()
    pygame.quit()

def main_settings_main_menu():
    clearscreen()
    clock=pygame.time.Clock()
    run=True
    window_fill_colour(Black)
    pygame.display.set_caption("Poker~Settings") 
    while run:
        clock.tick(FPS60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run=False
        
        settings_main_menu()
        pygame.display.update()
    pygame.quit()

def main_info_main_menu():
    clearscreen()
    clock=pygame.time.Clock()
    run=True
    window_fill_colour(Black)
    pygame.display.set_caption("Poker~Info")
    while run:
        clock.tick(FPS60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run=False
        
        info_main_menu()
        pygame.display.update()
    pygame.quit()

def main_how_to_play_main_menu():
    clearscreen()
    clock=pygame.time.Clock()
    run=True
    window_fill_colour(Black)
    pygame.display.set_caption("Poker~How to play")
    while run:
        clock.tick(FPS60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run=False
        
        how_to_play_main_menu()
        pygame.display.update()
    pygame.quit()
#}

if __name__ == "__main__":
    main_main_menu()